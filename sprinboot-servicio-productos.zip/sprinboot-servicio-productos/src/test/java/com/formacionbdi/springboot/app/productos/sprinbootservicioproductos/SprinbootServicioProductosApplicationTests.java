package com.formacionbdi.springboot.app.productos.sprinbootservicioproductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprinbootServicioProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
