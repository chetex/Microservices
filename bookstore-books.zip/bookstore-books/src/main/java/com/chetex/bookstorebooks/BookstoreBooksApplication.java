package com.chetex.bookstorebooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreBooksApplication.class, args);
	}

}
