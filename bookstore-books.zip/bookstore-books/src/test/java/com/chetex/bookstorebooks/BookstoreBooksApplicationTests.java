package com.chetex.bookstorebooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
