package com.chetex.bookstoreclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
